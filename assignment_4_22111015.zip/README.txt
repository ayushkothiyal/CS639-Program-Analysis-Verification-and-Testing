## There are 5 testcases (each containing 2 kachua programs) inside directory :-

	assignment_3_22111015\Kachua-Framework\KachuaCore\tests
	
	namely:- 

	test1.tl
	testb1.tl
	test2.tl
	testb2.tl
	test3.tl
	testb3.tl
	test4.tl
	testb4.tl
	test5.tl
	testb5.tl
	
## The outputs to above testcases are inside the folder :

	assignment_3_22111015\Kachua-Framework\KachuaCore\tests\outputs

	where, outputs of each testcase contains :-
	
	-> Screenshot of the expected outputs of each tectcases showing the rank of each component.
		 
## Commands:- (To run testcases)

	there will be two programs one without fault and one with fault. so there will be just command to run those and give those test cases names.

## Commands to run each of the testcases :-

TESTCASE 1 :-

( inside KachuaCore folder )
python kachua.py --SBFL ./tests/test1.tl --buggy ./tests/testb1.tl -vars "[':x', ':y']" --timeout 10 --ntests 20 --popsize 20 --cxpb 1.0 --mutpb 1.0 --ngen 100 --verbose True


TESTCASE 2 :-

( inside KachuaCore folder )
python kachua.py --SBFL ./tests/test2.tl --buggy ./tests/testb2.tl -vars "[':x', ':y']" --timeout 10 --ntests 20 --popsize 20 --cxpb 1.0 --mutpb 1.0 --ngen 100 --verbose True


TESTCASE 3 :-

( inside KachuaCore folder )
python kachua.py --SBFL ./tests/test3.tl --buggy ./tests/testb3.tl -vars "[':x', ':y']" --timeout 10 --ntests 20 --popsize 20 --cxpb 1.0 --mutpb 1.0 --ngen 100 --verbose True

TESTCASE 4 :-

( inside KachuaCore folder )
python kachua.py --SBFL ./tests/test4.tl --buggy ./tests/testb4.tl -vars "[':x', ':y']" --timeout 10 --ntests 20 --popsize 20 --cxpb 1.0 --mutpb 1.0 --ngen 100 --verbose True

TESTCASE 5 :-

( inside KachuaCore folder )
python kachua.py --SBFL ./tests/test5.tl --buggy ./tests/testb5.tl -vars "[':x', ':y']" --timeout 10 --ntests 20 --popsize 20 --cxpb 1.0 --mutpb 1.0 --ngen 100 --verbose True


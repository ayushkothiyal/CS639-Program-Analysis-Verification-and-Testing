from z3 import *
import argparse
import json
import sys

sys.path.insert(0, '../KachuaCore/')

from sExecutionInterface import *
import z3solver as zs
from irgen import *
from interpreter import *
import ast

def example(s):
    # To add symbolic variable x to solver
    s.addSymbVar('x')
    s.addSymbVar('y')
    # To add constraint in form of string
    s.addConstraint('x==5+y')
    s.addConstraint('And(x==y,x>5)')
    # s.addConstraint('Implies(x==4,y==x+8')
    # To access solvers directly use s.s.<function of z3>()
    print("constraints added till now",s.s.assertions())
    # To assign z=x+y
    s.addAssignment('z','x+y')
    # To get any variable assigned
    print("variable assignment of z =",s.getVar('z'))

def checkEq(args,ir):

    file1 = open("../Submission/testData1.json","r+")
    testData1=json.loads(file1.read())
    file1.close()
    file2 = open("../Submission/testData2.json","r+")
    testData2=json.loads(file2.read())
    file2.close()

    s = zs.z3Solver()
    testData1 = convertTestData(testData1)
    testData2 = convertTestData(testData2)
    key_to_map1 = {}
    key_to_map2= {}
    
    for i in testData2:
        val_list = []
        j = list(testData2[i]['params'].keys())
        k = list(testData2[i]['params'].values())
        # t1_keys = list(testData.keys())
        # l = testData[t1_keys[0]]['constparams']
        # c1 = 0
        
        lst = testData1["1"]["constparams"]
        for new in lst:
            s.addSymbVar(new[1:])
        
        
        
        for index, t in enumerate(j):
            s.addAssignment(t,str(k[index]))

        for h in testData1: 
            for m in testData1[h]['constraints']:
                s.addConstraint(m)
            if(str(s.s.check()) == 'sat'):
                key_to_map1[i]=h
                val_list.append(h) 
            s.s.reset()
        key_to_map2[i]=val_list

    print('key to map1',key_to_map1)
    print('key to map2',key_to_map2)

    flag = 0
    for i in key_to_map2:
        if(len(key_to_map2[i])>1):
            flag = 1
            break

    lst = testData1["1"]["constparams"]
    for i in lst:
        s.addSymbVar(i[1:])
    
    if(flag==0):
        for i in key_to_map1:
            j = list(testData2[i]['params'].keys())
            k = list(testData2[i]['params'].values())
            for index, t in enumerate(j):
                s.addAssignment(t,str(k[index]))
            dick1 = testData2[i]['symbEnc']
            dick2 = testData1[key_to_map1[i]]['symbEnc']
            print("dick1",dick1)
            print("dick2",dick2)         
            for each in dick1:
                s.addConstraint(str(dick1[each])+"=="+str(dick2[each]))
    else:
        for i in key_to_map2:
            st = []
            j = list(testData2[i]['params'].keys())
            k = list(testData2[i]['params'].values())
            for index, t in enumerate(j):
                s.addAssignment(t,str(k[index]))
            
            dick1 = testData2[i]['symbEnc']
            orring_arr = []
            for thing in key_to_map2[i]:
                dick2 = testData1[thing]['symbEnc']
            # print("dick1",dick1)
            # print("dick2",dick2)
                for each in dick1:
                    st.append(str(dick1[each])+"=="+str(dick2[each]))
                st.append(testData1[thing]["constraints"][0])
                anding  = ','.join(st)
                anding = 'And('+anding+')'
                st=[]
                orring_arr.append(anding)
            orring  = ','.join(orring_arr)
            orring = 'Or('+orring+')'
            s.addConstraint(orring)
            
            # for each in dick1:
            #     s.addConstraint(str(dick1[each])+"=="+str(dick2[each]))
    print(s.s.check())
    
    print(s.s.model())




        

if __name__ == '__main__':
    cmdparser = argparse.ArgumentParser(
        description='symbSubmission for assignment Program Synthesis using Symbolic Execution')
    cmdparser.add_argument('progfl')
    cmdparser.add_argument(
        '-b', '--bin', action='store_true', help='load binary IR')
    cmdparser.add_argument(
        '-e', '--output', default=list(), type=ast.literal_eval,
        help="pass variables to kachua program in python dictionary format")
    args = cmdparser.parse_args()
    ir = loadIR(args.progfl)
    checkEq(args,ir)
    exit()

## There are 5 testcases inside directory :-

	assignment_2_22111015\Kachua-Framework_Fuzzing\KachuaCore\tests
	
	namely:- 

	TEST_1.tl
	TEST_2.tl
	TEST_3.tl
	TEST_4.tl
	TEST_5.tl

## The outputs to above testcases are inside the folder :

	assignment_2_22111015\Kachua-Framework_Fuzzing\KachuaCore\tests

#Commands:-

## To run the testcases for fuzzing the inputs :-
fuzz1 - python kachua.py -t 60 --fuzz test\fuzz1.tl -d"{':x' :100, ':y' : 112}"
fuzz2 - python kachua.py -t 60 --fuzz test\fuzz2.tl -d"{':x' :100, ':y' : 12, ':z' : 12}" 
fuzz3 - python kachua.py -t 60 --fuzz test\fuzz3.tl -d"{':x' :170, ':y' : 164}"
fuzz4 - python kachua.py -t 60 --fuzz test\fuzz4.tl -d"{':a' :347, ':b' : 164, ':c' :50, ':d' :42, ':e' :70,}"
fuzz5 - python kachua.py -t 60 --fuzz test\fuzz5.tl -d"{':x' :-100, ':y' : -112}"



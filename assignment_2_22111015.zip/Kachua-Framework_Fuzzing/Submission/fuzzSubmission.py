import collections
from xmlrpc.client import MAXINT, MININT
import numpy as np
from kast import kachuaAST
import sys
from z3 import *
sys.path.insert(0, "KachuaCore/interfaces/")
from interfaces.fuzzerInterface import *
sys.path.insert(0, '../KachuaCore/')

# Each input is of this type.
#class InputObject():
#    def __init__(self, data):
#        self.id = str(uuid.uuid4())
#        self.data = data
#        # Flag to check if ever picked
#        # for mutation or not.
#        self.pickedOnce = False
        
class CustomCoverageMetric(CoverageMetricBase):
    # Statements covered is used for
    # coverage information.
    def __init__(self):
        super().__init__()

    # TODO : Implement this
    def compareCoverage(self, curr_metric, total_metric):
        # must compare curr_metric and total_metric
        # True if Improved Coverage else False
        
        
        main_list = list(set(curr_metric) - set(total_metric))
        if(main_list):
            return (True)
        return (False)
        
        # if(collections.Counter(curr_metric)!= collections.Counter(total_metric)):
        #     return True
        # return False
    # TODO : Implement this
    def updateTotalCoverage(self, curr_metric, total_metric):
        # Compute the total_metric coverage and return it (list)
        # this changes if new coverage is seen for a
        # given input.
        total_metric = list(set(curr_metric) | set(total_metric)) 
        print("Updated list is ", total_metric)
        return total_metric

class CustomMutator(MutatorBase):
    def __init__(self):
        pass

    # TODO : Implement this
    def mutate(self, input_data, coverageInfo, irList):
        # Mutate the input data and return it
        # coverageInfo is of type CoverageMetricBase
        # Don't mutate coverageInfo
        # irList : List of IR Statments (Don't Modify)
        # input_data.data -> type dict() with {key : variable(str), value : int}
        # must return input_data after mutation.
        for i in input_data.data:
            input_data.data[i] = (input_data.data[i]|np.random.randint(MININT,MAXINT))^np.random.randint(MININT,MAXINT)
        
        per = (len(coverageInfo.total_metric))/(len(irList)+1)*100
        print("************************[[[ total percentage = {} ]]]************************".format(per))
        return input_data


# Reuse code and imports from
# earlier submissions (if any).

to run the testcases type the following in command prompt opened in the KachuaCore directory:

python kachua.py -r .\..\..\testcases\test1.tl
 
then to see the optimised kachua run 

python kachua.py -b -r .\optimized.kw
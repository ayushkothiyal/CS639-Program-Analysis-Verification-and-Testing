import copy
import math
import sys
from typing import overload

sys.path.insert(0, "../KachuaCore/")

import cfg.kachuaCFG as cfgK
import cfg.cfgBuilder as cfgB
from interfaces.dataFlowAnalysisInterface import  *
import kast.kachuaAST as kachuaAST
import dataFlowAnalysis as DFA
from irgen import removeInstruction as removeInstruction
from irgen import addInstruction as addInstruction

'''
    Class to work with lattice elements.
    Implement these functions as required.
'''
class latticeValue(latticeValueBase):

    '''Initialize lattice value'''
    def __init__(self, data):
        pass

    '''To display lattice values'''
    def __str__(self):
        pass

    '''To check whether lattice value is bot or not'''
    def isBot(self):
        pass

    '''To check whether lattice value is Top or not'''
    def isTop(self):
        pass

    '''Implement the meet operator'''
    def meet(self, other):
        pass

    '''Implement the join operator'''
    def join(self, other):
        pass

    '''partial order with the other lattice value'''
    def __le__(self, other):
        pass

    '''equality check with other lattice value'''
    def __eq__(self, other):
        pass

    '''
        Add here required lattice operations
    '''
    pass


class ForwardAnalysis():
    def __init__(self):
        pass

    '''
        This function is to initialize in of the basic block currBB
        Returns a dictinary {varName -> latticeValues}
        isStartNode is a flag for stating whether currBB is start basic block or not
    '''
    def initialize(self, currBB, isStartNode):
        val = {}
        #Your additional initialisation code if any
        return val

    # just a dummy equallity check function for dictionary
    def isEqual(self, dA, dB):
        for i in dA.keys():
            if i not in dB.keys():
                return False
            if dA[i] != dB[i]:
                return False
        return True

    '''
        Transfer function for basic block 'currBB' 
        args: In val for currBB, currBB
        Returns newly calculated values in a form of list
    '''
    def transferFunction(self, currBBIN, currBB):
        #implement your transfer function here
        instrname = []
        outVal = []
        if(currBB.name != 'END'):
            if(currBB.name != 'END'):
                instrname = str(currBB.instrlist[0][0]).split()
            if(instrname[0]=='penup'):
                outVal.append({'penOPT': 1})
            elif(instrname[0]=='pendown'):
                outVal.append({'penOPT': 0})
            elif(currBBIN['penOPT'] ):
                outVal.append({'penOPT': 1})
            else:
                outVal.append({'penOPT': 0})
            
        return outVal

    '''
        Define the meet operation. 
        Implement this function as required.
        Returns a dictinary {varName -> latticeValues}
    '''
    def meet(self, predList):
        assert isinstance(predList, list)
        meetVal = {'penOPT' :1}
        for i in predList:
            for j in i.keys():
                if(i[j] == 0):
                    meetVal = {'penOPT' :0}
        return meetVal

def analyzeUsingDFA(ir):
    '''
        get the cfg out of IR
        each basic block consists of single statement
    '''    # Create a list single statement basic blocks. 
    cfg = cfgB.buildCFG(ir, "cfg", True)
    # Dump the CFG diagram to a file 'cfgView.png'.  
    cfgB.dumpCFG(cfg, "cfgView")

    # call worklist and get the in/out values of each basic block
    bbIn, bbOut = DFA.worklistAlgorithm(cfg)
    # print("bbIn is {} and \n \nbbOut is {}".format(bbIn, bbOut))

    # NOTE: Implement your code below. Do not change anything above this line.
    # Implement your analysis according to the questions on each basic bloc
    temp = 0
    ismove = 0
    x =1
    d=0
    l = len(bbOut.keys())-2
    # print(str.split(str(ir[2][1])))
    # print(((ir[2][0]).expr))
    # print(type(ir[2][0]).__name__ == "MoveCommand")
    # print((ir[2][0].expr.val))
    while(l):
        if(bbOut[str(x-d)][0]['penOPT'] == 1 and type(ir[x][0]).__name__ == 'MoveCommand' and ir[x][0].direction == 'forward'):
            ismove = 1
            t = (str.split(str(ir[x][0])))
            temp += int(t[1])
            removeInstruction(ir, x)

        elif(bbOut[str(x-d)][0]['penOPT'] == 1 and type(ir[x][0]).__name__ == 'MoveCommand' and ir[x][0].direction == 'backward'):
            ismove =1
            t = (str.split(str(ir[x][0])))
            temp -= int(t[1])
            removeInstruction(ir, x)

        elif(bbOut[str(x-d)][0]['penOPT'] == 1 and type(ir[x][0]).__name__ == 'MoveCommand' and (ir[x][0].direction == 'right' or ir[x][0].direction == 'left')):
            addInstruction(ir, kachuaAST.MoveCommand('forward',temp), x)
            temp=0 
            x=x+1
            ismove =0
            d=d+1
        
        
        elif(type(ir[x][0]).__name__ != 'MoveCommand' and ismove ==1):
            addInstruction(ir, kachuaAST.MoveCommand('forward',temp), x)
            temp=0 
            ismove =0
            d=d+1
            l=l+1
        l=l-1
        # print(type(ir[x][0]).__name__, temp)
        x = x+1
    addInstruction(ir, kachuaAST.MoveCommand('forward',temp), x-1)
    
    # TODO: Return the optimized IR in optIR
    optIR = ir
    cfg = cfgB.buildCFG(ir, "cfg", True)
    # Dump the CFG diagram to a file 'cfgView.png'.  
    cfgB.dumpCFG(cfg, "cfgView")
    return optIR
